﻿using SqliteClass6.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace SqliteClass6
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class DetailContact : Page
    {
        Contacts currentContact = new Contacts();
        public DetailContact()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            currentContact = e.Parameter as Contacts;

            NametxtBx.Text = currentContact.Name;
            PhonetxtBx.Text = currentContact.PhoneNumber;
        }

        private void DeleteContact_Click(object sender, RoutedEventArgs e)
        {

        }

        private void UpdateContact_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
