﻿using SqliteClass6.Helpers;
using SqliteClass6.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace SqliteClass6
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ContactList : Page
    {
        ObservableCollection<Contacts> DB_ContactList = new ObservableCollection<Contacts>();
        DatabaseHelperClass db = new DatabaseHelperClass();

        public ContactList()
        {
            this.InitializeComponent();
        }

        private void AddContact_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(AddContact));
        }

        private void DeleteAll_Click(object sender, RoutedEventArgs e)
        {

        }

        private void listBoxobj_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listBoxobj.SelectedIndex != -1)
            {
                Contacts item = listBoxobj.SelectedItem as Contacts;//Get slected listbox item contact ID
                Frame.Navigate(typeof(DetailContact), item);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            DB_ContactList = db.ReadAllContacts();
            if(DB_ContactList.Count > 0)
            {
                //LINQ of C# .NET
                listBoxobj.ItemsSource = DB_ContactList.OrderByDescending( i => i.Id ).ToList();
            }
        }
    }
}
