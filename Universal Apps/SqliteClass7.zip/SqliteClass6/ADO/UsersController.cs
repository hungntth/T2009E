﻿using SqliteClass6.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqliteClass6.ADO
{
    class UsersController
    {
        SqlConnection conn;

        public UsersController()
        {
            conn = new SqlConnection("Data Source=DESKTOP-C3OPNT7;Initial Catalog=RegUser;User ID=sa;Password=12345678");
        }

        public int GetTotalUser()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();
            string sqlCount = " SELECT COUNT(Id) FROM Users";

            SqlCommand sqlCommand = new SqlCommand(sqlCount, conn );
            
            return Convert.ToInt32( sqlCommand.ExecuteScalar() );
        }

        public bool UpdateUser(User user)
        {
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();

            string updateQuery = String.Format("Update Users SET firstname='{0}', lastname = '{1}', email ='{2}' Where id = {3};",
                user.FirstName, user.LastName, user.Email, user.Id);

            SqlCommand updateCommand = new SqlCommand(updateQuery, conn);
            
            int number = updateCommand.ExecuteNonQuery();

            return (number > 0);
        }

        public List<User> GetAllUser()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();

            //generic
            List<User> listUser = new List<User>();
            SqlCommand sqlCommand = new SqlCommand("SELECT id, firstname, lastname, email FROM [Users]", conn);
            SqlDataReader dataReader = sqlCommand.ExecuteReader();

            if (dataReader.HasRows)
            {
                while (dataReader.Read())
                {
                    User user = new User();

                    user.Id = Convert.ToInt32(dataReader["id"]);
                    user.FirstName = dataReader["firstname"].ToString();
                    user.LastName = dataReader["lastname"].ToString();
                    user.Email = dataReader["email"].ToString();

                    listUser.Add(user);
                }
                dataReader.Close();
                sqlCommand.Dispose();
            }

            return listUser;
        }

    }
}
