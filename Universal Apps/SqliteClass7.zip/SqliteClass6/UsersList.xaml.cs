﻿using SqliteClass6.ADO;
using SqliteClass6.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace SqliteClass6
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class UsersList : Page
    {
        ObservableCollection<User> userList = null;
        UsersController userController = new UsersController();
        public UsersList()
        {
            this.InitializeComponent();


        }

        //private void btnConnectDB_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        List<User> listUser = userController.GetAllUser();
        //        string strDetail = "";

        //        if (listUser.Count > 0)
        //        {
        //            foreach (var item in listUser)
        //            {
        //                strDetail += item.Id + ", " + item.FirstName + ", " + item.LastName + ", " + item.Email + "\n";
        //            }
        //            txtDetails.Text = strDetail;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        string mess = ex.Message;
        //        throw;
        //    }
        //}

        private void btnUser_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    User user = new User();
            //    user.Id = 1;
            //    user.FirstName = "first name";
            //    user.LastName = "last name";
            //    user.Email = "Email@gmail.com";

            //    userController.UpdateUser(user);
            //}
            //catch (Exception ex)
            //{
            //    string mess = ex.Message;
            //    throw;
            //}

            int count = userController.GetTotalUser();
            MessageDialog dialog = new MessageDialog("User count = " + count);
            dialog.ShowAsync();

        }

        private void listBoxobj_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            userList = new ObservableCollection<User>(userController.GetAllUser() );
            if (userList.Count > 0)
            {
                //LINQ of C# .NET
                listBoxobj.ItemsSource = userList.OrderByDescending(i => i.Id).ToList();
            }
        }
    }
}
