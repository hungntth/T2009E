﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace FileStorage
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        StorageFile fle = null;

        public MainPage()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = Windows.UI.Xaml.Navigation.NavigationCacheMode.Enabled;
        }

        private async System.Threading.Tasks.Task OpenFile()
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            this.fle = await storageFolder.GetFileAsync("test.txt");
            lblRemark.Text = "The file '" + fle.Name + "' was loaded.";
        }

        private async System.Threading.Tasks.Task ReadFromFile()
        {
            using (IRandomAccessStream sessionRandomAccess = await this.fle.OpenAsync(FileAccessMode.Read))
            {
                if (sessionRandomAccess.Size > 0)
                {
                    byte[] array3 = new byte[sessionRandomAccess.Size];
                    await sessionRandomAccess.ReadAsync(array3.AsBuffer(0, (int)sessionRandomAccess.Size), 
                        (uint)sessionRandomAccess.Size, InputStreamOptions.Partial);
                    string reRead = Encoding.UTF8.GetString(array3.ToArray(), 0, (int)array3.Length);
                    txtRemark.Text = this.fle.Name + " Content - " + Environment.NewLine + Environment.NewLine + reRead;
                }
                else
                {
                    lblRemark.Text = "File is empty";
                }
            }
        }

        private async void ButtonWrite_Click(object sender, RoutedEventArgs e)
        {
            StorageFile file = this.fle;
            if (file != null)
            {
                string userContent = txtRemark.Text;
                if (!String.IsNullOrEmpty(userContent))
                {
                    using (IRandomAccessStream sessionRandomAccess = await file.OpenAsync(FileAccessMode.ReadWrite))
                    {
                        Stream stream = sessionRandomAccess.AsStreamForWrite();
                        if (stream.Length > 0)
                        {
                            stream.Seek(stream.Length, SeekOrigin.Begin);
                        }

                        byte[] array = Encoding.UTF8.GetBytes(userContent);
                        stream.SetLength(stream.Length + array.Length);
                        await stream.WriteAsync(array, 0, array.Length);
                        await stream.FlushAsync();
                        await sessionRandomAccess.FlushAsync();
                    }
                    //ResetScenarioOutput();
                    await ReadFromFile();
                }
                else
                {
                    lblRemark.Text = @"The text box is empty, please write something and then click ‘Write’ again.";
                }
            }
            else
            {
                lblRemark.Text = @"File not open!";
            }
        }

        private async void ButtonRead_Click(object sender, RoutedEventArgs e)
        {
            if (this.fle == null)
            {
                await OpenFile();
            }
            if (this.fle != null)
            {
                await ReadFromFile();
            }

            else
            {
                lblRemark.Text = @"Create the file to read / write.";
            }
        }

        private async void ButtonCreate_Click(object sender, RoutedEventArgs e)
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            this.fle = await storageFolder.CreateFileAsync("test.txt", CreationCollisionOption.ReplaceExisting);
            lblRemark.Text = fle.Name + " created.";
        }

        private async void ButtonDeleteFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StorageFile file = this.fle;
                if (file != null)
                {
                    string fne = file.Name;
                    await file.DeleteAsync();
                    this.fle = null;
                    lblRemark.Text = fne + "' is deleted";
                }
            }
            catch (FileNotFoundException)
            {
                lblRemark.Text = @"File can not found.";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Next Page
            this.Frame.Navigate(typeof(NextPage));
        }
    }
}
