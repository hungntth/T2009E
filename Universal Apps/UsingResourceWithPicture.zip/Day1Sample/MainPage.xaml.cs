﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Resources.Core;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Day1Sample
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void ddlLang_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //if (lang.Equals("vi"))
            //{
            //    //change language
            //    var culture = new CultureInfo("vi-VN");
            //    Windows.Globalization.ApplicationLanguages.PrimaryLanguageOverride = culture.Name;
            //    CultureInfo.DefaultThreadCurrentCulture = culture;
            //    CultureInfo.DefaultThreadCurrentUICulture = culture;
            //}
            //else
            //{
            //    //change language
            //    var culture = new CultureInfo("en-US");
            //    Windows.Globalization.ApplicationLanguages.PrimaryLanguageOverride = culture.Name;
            //    CultureInfo.DefaultThreadCurrentCulture = culture;
            //    CultureInfo.DefaultThreadCurrentUICulture = culture;
            //}
        }

        private void ChangeLanguage_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            if (b != null)
            {
                var context = new ResourceContext(); //vi OR en
                var lang = ddlLang.SelectedValue;

                if (lang != null)
                {
                    var strlang = new List<string>();
                    strlang.Add(lang.ToString());
                    context.Languages = strlang;
                    var rstring = ResourceManager.Current.MainResourceMap.GetSubtree("Resources");
                    HelloTxt.Text = rstring.GetValue("hello", context).ValueAsString;

          
                    BitmapImage bitmapImage = new BitmapImage();

                    String flagPath = "ms-appx:///Assets/";
                    flagPath += rstring.GetValue("flag", context).ValueAsString;

                    Uri uri = new Uri(flagPath);
                    bitmapImage.UriSource = uri;
                    MyFlag.Source = bitmapImage;

                }
            }
        }
    }
}
