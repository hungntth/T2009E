﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Resources.Core;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Class8_2009E
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        SqlConnection conn;
        public MainPage()
        {
            this.InitializeComponent();

            conn = new SqlConnection("Data Source=DESKTOP-C3OPNT7;Initial Catalog=RegUser;Persist Security Info=True;User ID=sa;Password=12345678");

        }

        //private async void btnConnect_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        if (conn.State == System.Data.ConnectionState.Closed)
        //            conn.Open();

        //        MessageDialog mess = new MessageDialog("Connected");
        //        await mess.ShowAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageDialog mess = new MessageDialog(ex.Message);
        //        await mess.ShowAsync();
        //    }
        //}

        private void ddlLang_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var context = new ResourceContext();
            var lang = ddlLang.SelectedValue;
            //MessageDialog dialog = new MessageDialog(lang.ToString());

            //await dialog.ShowAsync();

            if (lang != null)
            {
                var strlang = new List<string>();
                strlang.Add(lang.ToString());
                context.Languages = strlang;

                var rstring = ResourceManager.Current.MainResourceMap.GetSubtree("Resources");
                txtTitle.Text = rstring.GetValue("title", context).ValueAsString;
                txtFirstName.Text = rstring.GetValue("firstname", context).ValueAsString;
                txtLastName.Text = rstring.GetValue("lastname", context).ValueAsString;
                txtEmail.Text = rstring.GetValue("email", context).ValueAsString;
                txtLanguage.Text = rstring.GetValue("language", context).ValueAsString;
                btnSave.Content = rstring.GetValue("save", context).ValueAsString;
            }
        }
    }
}
