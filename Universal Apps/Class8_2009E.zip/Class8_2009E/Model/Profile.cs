﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class8_2009E.Model
{
    public class Profile
    {
        public string ProfileImage { get; set; }
        public string StudentName { get; set; }
        public int StudentAge { get; set; }
    }

    public class ProfileManager
    {
        public static List<Profile> GetAllProfiles()
        {
            var items = new List<Profile>();

            items.Add(new Profile() { ProfileImage = "Assets/ProfileImages/hussain.jpg", StudentName = "Hussain", StudentAge = 21 });
            items.Add(new Profile() { ProfileImage = "Assets/ProfileImages/mudassir Shah.jpg", StudentName = "Shah", StudentAge = 22 });
            items.Add(new Profile() { ProfileImage = "Assets/ProfileImages/hussain.jpg", StudentName = "hussain", StudentAge = 23 });
            items.Add(new Profile() { ProfileImage = "Assets/ProfileImages/samar.jpg", StudentName = "samar", StudentAge = 24 });
            items.Add(new Profile() { ProfileImage = "Assets/ProfileImages/usman sheikh.jpg", StudentName = "sheikh", StudentAge = 25 });

            return items;
        }
    }
}
